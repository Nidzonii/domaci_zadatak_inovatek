﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InovatekZadatak
{
    class PomocnaKlasa
    {
        private string[] gradovi;
        private int[,] udaljenostIzmedjuGradova;
        private int brojLinija;
        private string fajlSaGradovima;
        private string fajlSaRastojanjima;

        public PomocnaKlasa(string fajlSaGradovima, string fajlSaRastojanjima)
        {
            this.fajlSaGradovima = fajlSaGradovima;
            this.fajlSaRastojanjima = fajlSaRastojanjima;

            try
            {
                brojLinija = File.ReadAllLines("../../" + fajlSaGradovima).Length;
            }catch(Exception e)
            {
                Console.WriteLine(e);
            }
            gradovi = new string[brojLinija];
            udaljenostIzmedjuGradova = new int[brojLinija, brojLinija];
        } 

        public string[] PristupListiGradovi()
        {
            return gradovi;
        }

        public int PristupDuziniFajla()
        {
            return brojLinija;
        }

        public int[,] PristupUdaljenostiIzmedjuGradova()
        {
            return udaljenostIzmedjuGradova;
        }

        public string[] NadjiGradove()
        {
            try
            {
                using (StreamReader sr = new StreamReader("../../" + fajlSaGradovima))
                {
                    for (int i = 0; i < brojLinija; i++)
                    {
                        gradovi[i] = sr.ReadLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Ne postoji traženi fajl! -> " + e);
            }

            return gradovi;
        }

        public int PronadjiIndeksGrada(string imeGrada)
        {
            return Array.IndexOf(gradovi, imeGrada);
        }

        public int[,] PronadjiUdaljenostIzmedjuGradova()
        {
            try
            {
                using (StreamReader sr = new StreamReader("../../"+fajlSaRastojanjima))
                {
                    for (int i = 0; i < brojLinija; i++)
                    {
                        var linija = sr.ReadLine();
                        var razdvojeno = linija.Split(',');
                        udaljenostIzmedjuGradova[PronadjiIndeksGrada(razdvojeno[0]), PronadjiIndeksGrada(razdvojeno[1])] = Convert.ToInt32(razdvojeno[2]);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Ne postoji traženi fajl! -> " + e);
            }

            return udaljenostIzmedjuGradova;
        }

        public void Dajkstra()
        {
            int i = 0; //Kreni od izvorista - Pariz
            int[] udaljenosti = new int[gradovi.Length];
            int[] krajnjeVrednosti = new int[gradovi.Length];
            string[] prethodniCvor = new string[gradovi.Length];

            while (true) {
                for (int ii = i; ii < i + 1; ii++)
                {
                    for (int j = 0; j < udaljenostIzmedjuGradova.GetLength(0); j++)
                    {
                        if (krajnjeVrednosti[j] == 0 && udaljenostIzmedjuGradova[ii, j] != 0)
                        {
                            udaljenosti[j] = udaljenostIzmedjuGradova[ii, j] + krajnjeVrednosti[ii];
                            krajnjeVrednosti[j] = udaljenostIzmedjuGradova[ii, j] + krajnjeVrednosti[ii];
                            prethodniCvor[j] = gradovi[ii];
                        }
                        else if (udaljenostIzmedjuGradova[ii, j] + krajnjeVrednosti[ii]< krajnjeVrednosti[j] && udaljenostIzmedjuGradova[ii, j] != 0)
                        {
                            udaljenosti[j] = udaljenostIzmedjuGradova[ii, j] + krajnjeVrednosti[ii];
                            krajnjeVrednosti[j] = udaljenostIzmedjuGradova[ii, j] + krajnjeVrednosti[ii];
                            prethodniCvor[j] = gradovi[ii];
                        }
                    }
                }
                if (ProveraObilaskaSvihCvorova(udaljenosti))
                {
                    break;
                }
                i = IndeksMinimumaUNizu(udaljenosti);
                udaljenosti[i] = 0;
            }

            StringBuilder sb = new StringBuilder();
            using (StreamWriter sw = new StreamWriter("../../result.txt"))
            {
                for (int indeks = 0; indeks < krajnjeVrednosti.Length; indeks++)
                {
                    if (prethodniCvor[indeks] != gradovi[0] && prethodniCvor[indeks] != null)
                    {
                        sb.Append(prethodniCvor[indeks]);
                        sw.WriteLine(gradovi[0] + "," + sb + "," + gradovi[indeks] + "," + krajnjeVrednosti[indeks]);
                        sb.Clear();
                    }
                    else
                    {
                        sw.WriteLine(gradovi[0] + "," + gradovi[indeks] + "," + krajnjeVrednosti[indeks]);
                    }
                }
                Console.WriteLine("Uspesno pronadjene najkrace putanje do zeljenih gradova");
            }
        }

        public int IndeksMinimumaUNizu(int[] niz)
        {
            int minimum = 100000;
            for(int i = 1; i < niz.Length; i++)
            {
                if(niz[i] < minimum && niz[i] != 0)
                {
                    minimum = niz[i];
                }
            }

            return Array.IndexOf(niz,minimum);
        }

        public bool ProveraObilaskaSvihCvorova(int[] niz)
        {
            bool fleg = true;
            for(int i = 0; i < niz.Length; i++)
            {
                if(niz[i] != 0)
                {
                    fleg = false;
                }
            }

            return fleg;
        }
    }
}
