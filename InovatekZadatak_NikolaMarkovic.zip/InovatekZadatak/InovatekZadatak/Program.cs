﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InovatekZadatak
{
    class Program
    {
        static void Main(string[] args)
        {
            PomocnaKlasa pk = new PomocnaKlasa("cities.txt", "distances.txt");
            pk.NadjiGradove();
            pk.PronadjiUdaljenostIzmedjuGradova();
            pk.Dajkstra();
            Console.ReadLine();
        }
    }
}
